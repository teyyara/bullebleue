(function(){
  var root=document.documentElement;
  /* menu mobile (le menu reste visible sans JavaScript) */
  var bg=document.querySelector('.burger'),nav=document.getElementById('nav');
  function closeMenu(){nav.classList.remove('open');bg.setAttribute('aria-expanded','false')}
  if(bg&&nav){
    bg.addEventListener('click',function(){var o=nav.classList.toggle('open');bg.setAttribute('aria-expanded',String(o))});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&nav.classList.contains('open')){closeMenu();bg.focus()}});
  }
  /* la fresque glisse avec le défilement, sauf si « sans animation » ou mouvement réduit */
  var R=2008/857;
  var oval=document.getElementById('oval'),mf=document.getElementById('mfresque');
  function still(){return root.classList.contains('rm')||(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches)}
  function pan(box,ih){var img=box.firstElementChild;img.style.height=ih+'px';var iw=ih*R,max=iw-box.clientWidth;var h=document.documentElement,p=still()?0:Math.min(1,window.scrollY/Math.max(1,h.scrollHeight-innerHeight));img.style.width=iw+'px';img.style.left=(-p*max)+'px'}
  function upd(){if(oval&&oval.offsetParent!==null)pan(oval,430);if(mf&&mf.offsetParent!==null)pan(mf,360)}
  var t=false;addEventListener('scroll',function(){if(t)return;t=true;requestAnimationFrame(function(){t=false;upd()})},{passive:true});
  addEventListener('resize',upd);document.addEventListener('a11ychange',upd);upd();
})();
