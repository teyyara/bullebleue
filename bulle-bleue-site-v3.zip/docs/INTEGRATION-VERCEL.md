# Mettre à jour le Vercel avec cette version

Le site est **statique** : il n'y a rien à compiler.

## Si le projet Vercel est relié à un dépôt GitHub
1. Dans le dépôt, supprimer l'ancien contenu (tout sauf `.git`).
2. Copier le contenu de ce dossier à la racine du dépôt (`index.html`, `css/`, `js/`, `fonts/`, `img/`, `vercel.json`…).
3. `git add -A && git commit -m "Nouvelle version du site (maquette 3, accessibilité)" && git push`.
4. Vercel redéploie tout seul. Ouvrir l'URL « Preview » pour vérifier.

## Réglages du projet dans Vercel (Settings → General → Build & Development)
- Framework Preset : **Other**
- Build Command : *(vide)*
- Output Directory : *(vide ou `.`)*
- Install Command : *(vide)*

## Sans GitHub
Déposer le dossier par glisser-déposer sur vercel.com/new, ou `npx vercel --prod` dans le dossier.

## Vérifications après déploiement
- Les 4 pages s'ouvrent (`/`, `/facile-a-lire`, `/accessibilite`, une adresse inexistante → 404).
- Le bouton « Accessibilité » (en bas à gauche) s'ouvre et les réglages fonctionnent.
- La console du navigateur ne montre aucune erreur. Si une ressource est bloquée, c'est la politique de sécurité (`vercel.json`) : ne pas ajouter de script externe sans la modifier.
- Remplacer `VOTRE-DOMAINE` dans `robots.txt` et `sitemap.xml` quand le domaine est connu.

## Ajouter une page
Copier `facile-a-lire.html`, changer le titre, la description et le contenu de `<main>`, ajouter le lien dans le menu des pages. Suivre la liste de contrôle de `docs/ACCESSIBILITE.md`.
