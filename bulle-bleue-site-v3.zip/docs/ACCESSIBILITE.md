# Accessibilité et inclusion

## Ce qui est inclus
- **Barre « Accessibilité »** (toutes les pages) : taille du texte (4 niveaux), police OpenDyslexic, espacement renforcé, contraste renforcé, suppression des animations, mode calme (dessins décoratifs masqués). Lien « Signaler un problème » dans le panneau et le pied de page. Réglages mémorisés dans le navigateur (localStorage), jamais envoyés.
- **Lecture à voix haute** (API Web Speech, voix française de l'appareil) : bouton « Écouter cette partie » dans 6 sections + « Écouter toute la page », 3 vitesses (lente 0,6 / normale / rapide 1,4), arrêt possible, annonce vocale du statut pour lecteurs d'écran.
- **Page « Facile à lire »** : phrases courtes, inspirée du FALC.
- Respect des réglages du système : `prefers-reduced-motion`, `prefers-contrast`, contraste forcé Windows.
- Texte en `rem` (suit la taille choisie dans le navigateur), police Atkinson Hyperlegible Next.
- Clavier : lien d'évitement, focus visible, Échap ferme le menu et le panneau.
- Sémantique : un seul h1, titres ordonnés, `lang="fr"`, textes alternatifs, `abbr` pour TDAH, flèches décoratives masquées.
- Fonctionne sans JavaScript (menu visible, contenu lisible).
- Tests automatiques axe-core (WCAG 2.2 AA) : 0 violation sur les 4 pages et avec tous les réglages activés ; pas de débordement horizontal à 390 px, même avec texte « Très grand » et police dyslexie.

## Limites à connaître
- Les tests automatiques ne détectent qu'une partie des problèmes. À faire : lecteur d'écran (NVDA, VoiceOver), zoom 200 % et 400 %, navigation clavier complète, essai avec de vraies personnes concernées.
- La qualité de la voix dépend de l'appareil et du navigateur. Pour les Actualités, prévoir si possible un fichier audio (mp3) enregistré par article.
- OpenDyslexic : les études sur son efficacité sont partagées ; l'espacement aéré a de meilleures preuves. Les deux sont proposés, au choix de la personne.
- La page « Facile à lire » n'est pas labellisée FALC : une relecture par des personnes concernées est nécessaire.
- La déclaration d'accessibilité est un texte provisoire. Ne pas affirmer de conformité RGAA sans audit. Vérifier si l'obligation s'applique à l'association.

## Liste de contrôle pour chaque nouvelle page ou actualité
1. Un seul `h1`, titres sans saut de niveau.
2. Chaque image : `alt` utile (ou `alt=""` si décorative).
3. Liens explicites (pas « cliquez ici »).
4. Phrases courtes, un résumé en tête pour les longs textes.
5. Ajouter `data-listen` sur la section pour avoir le bouton « Écouter ».
6. Documents (PDF) : texte réel (pas une image), titre, version accessible si possible.
7. Vidéos : sous-titres et transcription.
8. Tester : Tab seulement, zoom 200 %, réglages « Très grand » + dyslexie, axe-core.

## Couleurs (contrastes vérifiés, seuils WCAG : 4,5:1 texte, 3:1 gros texte et contours)
| Couple | Ratio | Usage autorisé |
|---|---|---|
| Encre #1F2430 sur tangerine #FF8A1F | 6,58 | Texte des boutons : OK |
| Marine #223C84 sur tangerine | 4,35 | Gros texte uniquement |
| Blanc sur tangerine | 2,36 | Jamais (ni texte ni contour essentiel) |
| Vert #638473 sur blanc | 4,14 | Contours et gros texte seulement (sinon #5E7D6D) |
| Marine sur bleu clair #BFCDE1 | 6,37 | OK |
Samedi et mercredi sont distingués par le texte, pas seulement par la couleur du cadre.

## Choisir l'outil de publication (quand l'association publiera elle-même)
Recommandations ATAG : l'outil doit être accessible et aider à produire du contenu accessible.
- Utilisable au clavier et au lecteur d'écran par un bénévole
- Texte alternatif demandé à chaque image
- Niveaux de titres guidés
- Aperçu avant publication, rappel des règles sur l'écran d'édition

## Mesure d'audience
Aucune pour l'instant. Si un jour : outil anonymisé (sans cookie publicitaire), possibilité de refuser, à ajouter dans la CSP de vercel.json.

## Référentiels
Cible : WCAG 2.2 niveau AA (le RGAA 4 en découle). Le MOOC Inria s'appuyait sur WCAG 2.0 / RGAA 3 : les critères mobiles récents (taille des cibles, réorganisation à 320 px) ont été ajoutés ici.
