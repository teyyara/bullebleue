# Tester le site avec de vraies personnes

Objectif : mesurer (pas déclarer) que chacun peut, seul, trouver l'information et obtenir le même résultat.

## Qui
Au moins 6 personnes aux profils variés : une personne dyslexique, une malvoyante, une senior sur téléphone, un ado, un aidant, une personne qui lit difficilement. Observer autant qu'interroger (certaines personnes ont du mal à exprimer leurs besoins).

## Tâches (une à la fois, sans aide)
1. Trouver le jour et l'heure de l'accueil des enfants.
2. Agrandir le texte, puis remettre le réglage par défaut.
3. Faire lire à voix haute la partie « Les sorties ».
4. Trouver comment écrire à l'association.
Noter : réussite oui/non, temps, hésitations, ce que la personne dit.

## Questionnaire (0 = pas d'accord … 4 = tout à fait d'accord)
Version en images (smileys) pour les personnes qui lisent difficilement.
- Autonomie : « Ce site me permet de choisir comment je lis et navigue. » / « Je peux régler le site comme j'en ai besoin. »
- Compétence : « Je trouve facilement ce que je cherche. » / « Je sais toujours où je suis sur le site. »
- Appartenance : « Ce site me donne envie de participer à la vie de l'association. » / « Je me reconnais dans ce site. »

## Ensuite
Corriger, puis refaire un tour de test. Garder les résultats (sans noms) dans ce dossier.
