# La Bulle Bleue — site de l'association APAiL

Site statique (HTML, CSS, JavaScript). Aucun outil de compilation, aucune dépendance.

## Contenu
- `index.html` : page d'accueil (maquette 3, « version posée »)
- `facile-a-lire.html` : présentation en phrases courtes
- `accessibilite.html` : déclaration d'accessibilité simple (texte provisoire à valider)
- `404.html` : page introuvable
- `css/style.css`, `js/` (`boot.js`, `a11y.js`, `main.js`), `fonts/` (polices hébergées localement), `img/`
- `vercel.json` : en-têtes de sécurité et cache

## Tester en local
```
python3 -m http.server 8000
```
puis ouvrir http://localhost:8000 (ne pas ouvrir le fichier directement : certaines polices ne se chargent pas).

## Mettre en ligne
Voir `docs/INTEGRATION-VERCEL.md`.

## Accessibilité
Voir `docs/ACCESSIBILITE.md` (ce qui est inclus, comment tester, liste de contrôle pour chaque nouvelle page).

## À faire avant la mise en ligne publique
Voir `docs/A-FAIRE.md`.
